/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.listas;

import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author camil
 */
public class Listas {
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Seleccione el tipo de lista:");
        System.out.println("1. Lista Simple");
        System.out.println("2. Lista Circular");
        System.out.print("Ingrese la opción deseada: ");

        try {
            int tipoLista = scanner.nextInt();

            if (tipoLista == 1) {
                List<Integer> listaSimple = new LinkedList<>();
                listaSimple.add(3);
                listaSimple.add(7);
                listaSimple.add(9);
                listaSimple.add(10);
                menuListaSimple(listaSimple, scanner);
            } else if (tipoLista == 2) {
                List<Integer> listaCircular = new LinkedList<>();
                listaCircular.add(3);
                listaCircular.add(7);
                listaCircular.add(9);
                listaCircular.add(10);
                menuListaCircular(listaCircular, scanner);
            } else {
                System.out.println("Opción no válida. Saliendo del programa.");
            }

        } catch (InputMismatchException e) {
            System.out.println("Error: Debe ingresar un valor numérico.");
        }
    }

    private static void menuListaSimple(List<Integer> lista, Scanner scanner) {
        while (true) {
            System.out.println("\nMenú Lista Simple:");
            System.out.println("1. Agregar número al inicio");
            System.out.println("2. Eliminar número al final");
            System.out.println("3. Buscar elemento");
            System.out.println("4. Mostrar elementos");
            System.out.println("5. Mostrar cantidad de elementos");
            System.out.println("0. Salir");
            System.out.print("Ingrese la opción deseada: ");

            try {
                int opcion = scanner.nextInt();

                switch (opcion) {
                    case 1:
                        agregarAlInicio(lista, scanner);
                        break;
                    case 2:
                        eliminarAlFinal(lista);
                        break;
                    case 3:
                        buscarElemento(lista, scanner);
                        break;
                    case 4:
                        mostrarElementos(lista);
                        break;
                    case 5:
                        mostrarCantidadElementos(lista);
                        break;
                    case 0:
                        System.out.println("Saliendo del programa. ¡Hasta luego!");
                        System.exit(0);
                    default:
                        System.out.println("Opción no válida. Inténtelo de nuevo.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Debe ingresar un valor numérico.");
                scanner.nextLine(); // Limpiar el buffer del scanner
            }
        }
    }

    private static void menuListaCircular(List<Integer> lista, Scanner scanner) {
        while (true) {
            System.out.println("\nMenú Lista Circular:");
            System.out.println("1. Agregar número al final");
            System.out.println("2. Eliminar primer elemento");
            System.out.println("3. Buscar elemento");
            System.out.println("4. Mostrar elementos");
            System.out.println("5. Mostrar cantidad de elementos");
            System.out.println("0. Salir");
            System.out.print("Ingrese la opción deseada: ");

            try {
                int opcion = scanner.nextInt();

                switch (opcion) {
                    case 1:
                        agregarAlFinal(lista, scanner);
                        break;
                    case 2:
                        eliminarPrimerElemento(lista);
                        break;
                    case 3:
                        buscarElemento(lista, scanner);
                        break;
                    case 4:
                        mostrarElementos(lista);
                        break;
                    case 5:
                        mostrarCantidadElementos(lista);
                        break;
                    case 0:
                        System.out.println("Saliendo del programa. ¡Hasta luego!");
                        System.exit(0);
                    default:
                        System.out.println("Opción no válida. Inténtelo de nuevo.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Debe ingresar un valor numérico.");
                scanner.nextLine(); // Limpiar el buffer del scanner
            }
        }
    }

    private static void agregarAlInicio(List<Integer> lista, Scanner scanner) {
        System.out.print("Ingrese el número a agregar al inicio: ");
        try {
            int numero = scanner.nextInt();

            if (!lista.contains(numero)) {
                lista.add(0, numero);
                System.out.println("Número agregado correctamente.");
            } else {
                System.out.println("Error: El elemento ya existe en la lista. No se permiten elementos duplicados.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Debe ingresar un valor numérico.");
            scanner.nextLine(); // Limpiar el buffer del scanner
        }
    }

    private static void eliminarAlFinal(List<Integer> lista) {
        if (lista.isEmpty()) {
            System.out.println("La lista está vacía. No se puede eliminar ningún elemento.");
        } else {
            int elementoEliminado = lista.remove(lista.size() - 1);
            System.out.println("Se eliminó el elemento " + elementoEliminado + " al final de la lista.");
        }
    }

    private static void buscarElemento(List<Integer> lista, Scanner scanner) {
        System.out.print("Ingrese el número a buscar: ");
        try {
            int numero = scanner.nextInt();

            if (lista.contains(numero)) {
                System.out.println("El elemento " + numero + " está en la lista.");
            } else {
                System.out.println("El elemento " + numero + " no está en la lista.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Debe ingresar un valor numérico.");
            scanner.nextLine(); // Limpiar el buffer del scanner
        }
    }

    private static void mostrarElementos(List<Integer> lista) {
        System.out.println("Elementos de la lista:");
        for (int elemento : lista) {
            System.out.print(elemento + " ");
        }
        System.out.println();
    }

    private static void mostrarCantidadElementos(List<Integer> lista) {
        System.out.println("La cantidad de elementos en la lista es: " + lista.size());
    }

    private static void agregarAlFinal(List<Integer> lista, Scanner scanner) {
        System.out.print("Ingrese el número a agregar al final: ");
        try {
            int numero = scanner.nextInt();

            if (!lista.contains(numero)) {
                lista.add(numero);
                System.out.println("Número agregado correctamente.");
            } else {
                System.out.println("Error: El elemento ya existe en la lista. No se permiten elementos duplicados.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Error: Debe ingresar un valor numérico.");
            scanner.nextLine(); // Limpiar el buffer del scanner
        }
    }

    private static void eliminarPrimerElemento(List<Integer> lista) {
        if (lista.isEmpty()) {
            System.out.println("La lista está vacía. No se puede eliminar ningún elemento.");
        } else {
                        int elementoEliminado = lista.remove(0);
            System.out.println("Se eliminó el primer elemento " + elementoEliminado + " de la lista.");
        }
    }
}
        